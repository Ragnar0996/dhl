@extends('layouts.menu')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <br>
            <h1 class="h2" align="center">
                ENCIERROS Y DEPOSITOS DE VEHICULOS

            </h1>
            <br>
            <div align="center">
                <img src="{{asset('img/car.png')}}" width="600px" height="600px" />
            </div>

        </div>
    </div>
</div>
@endsection
