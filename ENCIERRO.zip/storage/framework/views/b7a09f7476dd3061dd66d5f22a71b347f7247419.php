

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <br>
            <h1 class="h2" align="center">
                COMITE MUNICIPAL DEL SISTEMA DIF

            </h1>
            <br>
            <div align="center">
                <img src="<?php echo e(asset('img/doctores.png')); ?>" width="600px" height="300px" />
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\DIF\resources\views/home.blade.php ENDPATH**/ ?>